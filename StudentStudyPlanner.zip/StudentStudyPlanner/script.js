


"use strict";


// Student Study Planner prototype
// Data is stored locally in this browser, not on an online server.

const STORAGE_KEY = "studentStudyPlanner_v1";

const $ = (id) => document.getElementById(id);

let deadlines = [];
let sessions = [];
let currentWeek = startOfWeek(new Date());
let selectedSessionId = null;
let noticeTimer = null;

function makeId() {
    if (window.crypto && typeof window.crypto.randomUUID === "function") {
        return window.crypto.randomUUID();
    }

    return Date.now().toString(36) + Math.random().toString(36).slice(2);
}

function loadData() {
    try {
        const saved = localStorage.getItem(STORAGE_KEY);

        if (saved) {
            const data = JSON.parse(saved);
            deadlines = Array.isArray(data.deadlines) ? data.deadlines : [];
            sessions = Array.isArray(data.sessions) ? data.sessions : [];
        }
    } catch (error) {
        deadlines = [];
        sessions = [];
        console.error("Could not load saved planner data:", error);
    }
}

function saveData() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify({
            deadlines,
            sessions
        }));
        return true;
    } catch (error) {
        console.error("Could not save planner data:", error);
        showNotice(
            "Your browser could not save the changes. Check its storage settings.",
            true
        );
        return false;
    }
}

function dateFromISO(value) {
    if (!value) return null;

    const parts = value.split("-").map(Number);

    if (parts.length !== 3 || parts.some(Number.isNaN)) {
        return null;
    }

    const date = new Date(parts[0], parts[1] - 1, parts[2]);
    date.setHours(0, 0, 0, 0);

    return date;
}

function dateISO(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");

    return `${year}-${month}-${day}`;
}

function todayISO() {
    return dateISO(new Date());
}

function formatDate(value, options = {}) {
    const date = dateFromISO(value);

    if (!date) return "Date not set";

    return date.toLocaleDateString("en-ZA", {
        day: "numeric",
        month: "short",
        year: "numeric",
        ...options
    });
}

function formatTime(value) {
    if (!value) return "";

    const parts = value.split(":").map(Number);

    if (parts.length < 2 || parts.some(Number.isNaN)) {
        return value;
    }

    const date = new Date();
    date.setHours(parts[0], parts[1], 0, 0);

    return date.toLocaleTimeString("en-ZA", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false
    });
}

function startOfWeek(date) {
    const result = new Date(date);
    result.setHours(0, 0, 0, 0);

    const day = result.getDay();
    const difference = day === 0 ? -6 : 1 - day;

    result.setDate(result.getDate() + difference);
    return result;
}

function addDays(date, amount) {
    const result = new Date(date);
    result.setDate(result.getDate() + amount);
    return result;
}

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, (character) => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[character]);
}

function showNotice(message, isError = false) {
    const notice = $("notice");

    clearTimeout(noticeTimer);

    notice.textContent = message;
    notice.classList.toggle("error", isError);
    notice.hidden = false;

    noticeTimer = setTimeout(() => {
        notice.hidden = true;
    }, 5000);
}

function showPage(pageId) {
    const page = $(pageId);

    if (!page || !page.classList.contains("page")) return;

    document.querySelectorAll(".page").forEach((section) => {
        section.hidden = section.id !== pageId;
    });

    document.querySelectorAll(".nav-button").forEach((button) => {
        const active = button.dataset.page === pageId;

        button.classList.toggle("active", active);

        if (active) {
            button.setAttribute("aria-current", "page");
        } else {
            button.removeAttribute("aria-current");
        }
    });

    const titles = {
        dashboard: "Dashboard",
        deadlines: "Deadlines",
        schedule: "Weekly Schedule",
        sessions: "Study Sessions",
        assistant: "Study Assistant"
    };

    $("pageTitle").textContent = titles[pageId] || "Study Planner";
    $("notice").hidden = true;

    if (pageId === "schedule") renderSchedule();
    if (pageId === "assistant") $("chatInput").focus();
}

function updateDateLabel() {
    $("todayLabel").textContent = new Date().toLocaleDateString("en-ZA", {
        weekday: "short",
        day: "numeric",
        month: "short",
        year: "numeric"
    });
}

function sortedDeadlines() {
    return [...deadlines].sort((a, b) =>
        a.date.localeCompare(b.date) || a.title.localeCompare(b.title)
    );
}

function sortedSessions() {
    return [...sessions].sort((a, b) =>
        (a.date + "T" + a.start).localeCompare(b.date + "T" + b.start)
    );
}

function deadlineIsUpcoming(deadline) {
    return deadline.date >= todayISO();
}

function sessionIsUpcoming(session) {
    return !session.completed && session.date >= todayISO();
}

function updateDashboard() {
    const upcomingDeadlines = sortedDeadlines().filter(deadlineIsUpcoming);
    const plannedSessions = sortedSessions().filter(sessionIsUpcoming);
    const completed = sessions.filter(session => session.completed).length;
    const total = sessions.length;
    const percentage = total === 0 ? 0 : Math.round((completed / total) * 100);

    $("deadlineCount").textContent = upcomingDeadlines.length;
    $("sessionCount").textContent = plannedSessions.length;
    $("completedCount").textContent = completed;
    $("progressPercent").textContent = percentage + "%";
    $("progressFill").style.width = percentage + "%";
    $("progressBar").setAttribute("aria-valuenow", String(percentage));

    if (total === 0) {
        $("progressMessage").textContent =
            "Plan your first session to begin tracking progress.";
    } else if (percentage === 100) {
        $("progressMessage").textContent =
            "Excellent! All your recorded study sessions are complete.";
    } else {
        $("progressMessage").textContent =
            `${completed} of ${total} recorded sessions completed. Keep going at your own pace.`;
    }

    renderDeadlineItems("dashboardDeadlines", upcomingDeadlines.slice(0, 4), false);
    renderDeadlineItems("allDeadlines", sortedDeadlines(), true);

    renderSessionItems(
        "dashboardSessions",
        plannedSessions.slice(0, 4),
        false
    );

    renderSessionItems("allSessions", sortedSessions(), true);
    updateDeadlineSelect();
}

function emptyState(title, description) {
    return `
        <div class="empty-state">
            <strong>${escapeHTML(title)}</strong>
            <span>${escapeHTML(description)}</span>
        </div>
    `;
}

function renderDeadlineItems(containerId, items, showActions) {
    const container = $(containerId);

    if (!items.length) {
        container.innerHTML = emptyState(
            "No deadlines yet",
            "Add an academic deadline to get started."
        );
        return;
    }

    container.innerHTML = items.map(deadline => {
        const past = deadline.date < todayISO();

        return `
            <div class="deadline-item">
                <div class="item-main">
                    <strong>${escapeHTML(deadline.title)}</strong>
                    <p>${escapeHTML(deadline.subject)} · ${escapeHTML(deadline.type)}</p>
                    ${past ? '<p>Past due date</p>' : ""}
                    ${showActions && deadline.description
                        ? `<p>${escapeHTML(deadline.description)}</p>` : ""}
                    ${showActions ? `
                        <div class="item-actions">
                            <button type="button" class="small-button"
                                data-action="edit-deadline" data-id="${escapeHTML(deadline.id)}">
                                Edit
                            </button>
                            <button type="button" class="small-button"
                                data-action="plan-from-deadline" data-id="${escapeHTML(deadline.id)}">
                                Plan study
                            </button>
                            <button type="button" class="small-button danger"
                                data-action="delete-deadline" data-id="${escapeHTML(deadline.id)}">
                                Delete
                            </button>
                        </div>` : ""}
                </div>
                <span class="item-date">${escapeHTML(formatDate(deadline.date, {
                    year: undefined
                }))}</span>
            </div>
        `;
    }).join("");
}

function renderSessionItems(containerId, items, showActions) {
    const container = $(containerId);

    if (!items.length) {
        container.innerHTML = emptyState(
            "No study sessions yet",
            "Create a study session to organise your time."
        );
        return;
    }

    container.innerHTML = items.map(session => `
        <div class="session-item">
            <div class="item-main">
                <strong>${escapeHTML(session.title)}</strong>
                <p>${escapeHTML(session.subject)} · ${escapeHTML(formatDate(session.date))}</p>
                <p>${escapeHTML(formatTime(session.start))} · ${escapeHTML(session.duration)} minutes</p>
                ${session.shared && session.partner
                    ? `<p>Shared with ${escapeHTML(session.partner)}</p>` : ""}
                ${session.completed ? '<p>✓ Completed</p>' : ""}
                ${showActions ? `
                    <div class="item-actions">
                        <button type="button" class="small-button"
                            data-action="view-session" data-id="${escapeHTML(session.id)}">
                            Details
                        </button>
                        ${!session.completed ? `
                            <button type="button" class="small-button"
                                data-action="complete-session" data-id="${escapeHTML(session.id)}">
                                Mark complete
                            </button>` : ""}
                        <button type="button" class="small-button"
                            data-action="edit-session" data-id="${escapeHTML(session.id)}">
                            Edit
                        </button>
                        <button type="button" class="small-button danger"
                            data-action="delete-session" data-id="${escapeHTML(session.id)}">
                            Delete
                        </button>
                    </div>` : ""}
            </div>
            <span class="item-date">${session.completed ? "Completed" : "Planned"}</span>
        </div>
    `).join("");
}

function updateDeadlineSelect() {
    const select = $("sessionDeadline");
    const previous = select.value;

    select.innerHTML = '<option value="">No linked deadline</option>';

    sortedDeadlines().forEach(deadline => {
        const option = document.createElement("option");
        option.value = deadline.id;
        option.textContent = `${deadline.title} (${formatDate(deadline.date)})`;
        select.appendChild(option);
    });

    if (deadlines.some(deadline => deadline.id === previous)) {
        select.value = previous;
    }
}

function resetDeadlineForm() {
    $("deadlineForm").reset();
    $("deadlineId").value = "";
    $("deadlineFormHeading").textContent = "Add a deadline";
    $("deadlineSubmit").textContent = "Save deadline";
}

function resetSessionForm() {
    $("sessionForm").reset();
    $("sessionId").value = "";
    $("sessionFormHeading").textContent = "Create a study session";
    $("sessionSubmit").textContent = "Save study session";
    $("partnerField").hidden = true;
    $("partnerName").required = false;
    $("sessionShare").checked = false;
    $("sessionDate").value = todayISO();
}

function editDeadline(id) {
    const deadline = deadlines.find(item => item.id === id);
    if (!deadline) return;

    showPage("deadlines");

    $("deadlineId").value = deadline.id;
    $("deadlineTitle").value = deadline.title;
    $("deadlineType").value = deadline.type;
    $("deadlineSubject").value = deadline.subject;
    $("deadlineDate").value = deadline.date;
    $("deadlineDescription").value = deadline.description || "";

    $("deadlineFormHeading").textContent = "Edit deadline";
    $("deadlineSubmit").textContent = "Update deadline";

    $("deadlineTitle").focus();
}

function planFromDeadline(id) {
    const deadline = deadlines.find(item => item.id === id);
    if (!deadline) return;

    resetSessionForm();

    $("sessionTitle").value = `Study for ${deadline.title}`;
    $("sessionSubject").value = deadline.subject;
    $("sessionDeadline").value = deadline.id;
    $("sessionDate").value =
        deadline.date > todayISO() ? deadline.date : todayISO();

    showPage("sessions");
    $("sessionTitle").focus();
}

function editSession(id) {
    const session = sessions.find(item => item.id === id);
    if (!session) return;

    selectedSessionId = session.id;
    showPage("sessions");

    $("sessionId").value = session.id;
    $("sessionTitle").value = session.title;
    $("sessionDeadline").value = session.deadlineId || "";
    $("sessionSubject").value = session.subject;
    $("sessionDate").value = session.date;
    $("sessionStart").value = session.start;
    $("sessionDuration").value = String(session.duration);
    $("sessionNotes").value = session.notes || "";
    $("sessionShare").checked = Boolean(session.shared);
    $("partnerField").hidden = !session.shared;
    $("partnerName").required = Boolean(session.shared);
    $("partnerName").value = session.partner || "";

    $("sessionFormHeading").textContent = "Edit study session";
    $("sessionSubmit").textContent = "Update session";

    $("sessionTitle").focus();
}

function completeSession(id) {
    const session = sessions.find(item => item.id === id);
    if (!session || session.completed) return;

    session.completed = true;

    if (!saveData()) {
        session.completed = false;
        return;
    }

    refreshAll();
    showNotice("Study session completed. Your progress has been updated.");

    if ($("sessionDialog").open) {
        $("sessionDialog").close();
    }
}

function deleteDeadline(id) {
    const deadline = deadlines.find(item => item.id === id);
    if (!deadline) return;

    const linkedSessions = sessions.filter(item => item.deadlineId === id).length;

    const message = linkedSessions
        ? `Delete "${deadline.title}"? ${linkedSessions} linked study session(s) will remain, but will no longer be linked to this deadline.`
        : `Delete "${deadline.title}"?`;

    if (!confirm(message)) return;

    deadlines = deadlines.filter(item => item.id !== id);

    sessions.forEach(session => {
        if (session.deadlineId === id) session.deadlineId = "";
    });

    if (saveData()) {
        refreshAll();
        showNotice("Deadline deleted.");
    }
}

function deleteSession(id) {
    const session = sessions.find(item => item.id === id);
    if (!session) return;

    if (!confirm(`Delete the study session "${session.title}"?`)) return;

    sessions = sessions.filter(item => item.id !== id);

    if (saveData()) {
        refreshAll();
        showNotice("Study session deleted.");

        if ($("sessionDialog").open) {
            $("sessionDialog").close();
        }
    }
}

function renderSchedule() {
    const start = new Date(currentWeek);
    const end = addDays(start, 6);

    $("weekLabel").textContent =
        `${formatDate(dateISO(start))} – ${formatDate(dateISO(end))}`;

    const grid = document.createElement("div");
    grid.className = "schedule-grid";

    const corner = document.createElement("div");
    corner.className = "schedule-cell day-heading";
    corner.textContent = "Time";
    grid.appendChild(corner);

    const days = [];

    for (let i = 0; i < 7; i++) {
        const day = addDays(start, i);
        days.push(day);

        const heading = document.createElement("div");
        heading.className = "schedule-cell day-heading";
        heading.textContent = day.toLocaleDateString("en-ZA", {
            weekday: "short",
            day: "numeric"
        });

        grid.appendChild(heading);
    }

    // Show one column per day and rows for each hour.
    for (let hour = 7; hour <= 21; hour++) {
        const timeCell = document.createElement("div");
        timeCell.className = "schedule-cell time-heading";
        timeCell.textContent = `${String(hour).padStart(2, "0")}:00`;
        grid.appendChild(timeCell);

        for (const day of days) {
            const cell = document.createElement("div");
            cell.className = "schedule-cell";

            const dayValue = dateISO(day);
            const events = sortedSessions().filter(session => {
                if (session.date !== dayValue || !session.start) return false;

                const sessionHour = Number(session.start.split(":")[0]);
                return sessionHour === hour;
            });

            events.forEach(session => {
                const button = document.createElement("button");
                button.type = "button";
                button.className = "schedule-event";
                if (session.completed) button.classList.add("completed");

                button.dataset.action = "view-session";
                button.dataset.id = session.id;

                const title = document.createElement("strong");
                title.textContent = session.title;

                const time = document.createElement("small");
                time.textContent =
                    `${formatTime(session.start)} · ${session.duration} min`;

                button.append(title, time);
                cell.appendChild(button);
            });

            grid.appendChild(cell);
        }
    }

    $("weeklySchedule").replaceChildren(grid);
}

function openSessionDetails(id) {
    const session = sessions.find(item => item.id === id);
    if (!session) return;

    selectedSessionId = id;

    const deadline = deadlines.find(item => item.id === session.deadlineId);

    const rows = [
        ["Session", session.title],
        ["Subject", session.subject],
        ["Date", formatDate(session.date)],
        ["Start time", formatTime(session.start)],
        ["Duration", `${session.duration} minutes`],
        ["Linked deadline", deadline ? deadline.title : "None"],
        ["Study notes", session.notes || "No notes added"],
        ["Sharing", session.shared
            ? `Shared with ${session.partner || "study partner"} (simulated)`
            : "Not shared"],
        ["Status", session.completed ? "Completed" : "Planned"]
    ];

    $("sessionDetails").replaceChildren();

    rows.forEach(([label, value]) => {
        const row = document.createElement("div");
        row.className = "detail-row";

        const heading = document.createElement("strong");
        heading.textContent = label;

        const text = document.createElement("div");
        text.textContent = value;

        row.append(heading, text);
        $("sessionDetails").appendChild(row);
    });

    $("completeSessionButton").hidden = session.completed;
    $("completeSessionButton").disabled = session.completed;

    $("sessionDialog").showModal();
}



function checkReminders() {
    const now = new Date();
    const next24Hours = new Date(
        now.getTime() + 24 * 60 * 60 * 1000
    );

    const upcoming = sortedSessions().filter(session => {
        if (session.completed || !session.date || !session.start) {
            return false;
        }

        const sessionDate = dateFromISO(session.date);
        if (!sessionDate) return false;

        const [hours, minutes] = session.start.split(":").map(Number);
        sessionDate.setHours(hours, minutes, 0, 0);

        return sessionDate >= now && sessionDate <= next24Hours;
    });

    if (upcoming.length === 0) {
        showNotice(
            "No incomplete study sessions are scheduled in the next 24 hours."
        );
        return;
    }

    const summary = upcoming.map(session =>
        `${session.title} — ${formatDate(session.date)}, ${formatTime(session.start)}`
    ).join(" | ");

    showNotice("Upcoming study sessions: " + summary);
}



// Deadline form submission
$("deadlineForm").addEventListener("submit", event => {
    event.preventDefault();

    const id = $("deadlineId").value;
    const title = $("deadlineTitle").value.trim();
    const subject = $("deadlineSubject").value.trim();
    const date = $("deadlineDate").value;

    if (!title || !subject || !date) {
        showNotice("Please complete all required deadline fields.", true);
        return;
    }

    if (!dateFromISO(date)) {
        showNotice("Please enter a valid deadline date.", true);
        return;
    }

    const existing = deadlines.find(item => item.id === id);

    const deadline = {
        id: existing ? existing.id : makeId(),
        title,
        type: $("deadlineType").value,
        subject,
        date,
        description: $("deadlineDescription").value.trim()
    };

    if (existing) {
        deadlines = deadlines.map(item => item.id === id ? deadline : item);
    } else {
        deadlines.push(deadline);
    }

    if (saveData()) {
        resetDeadlineForm();
        refreshAll();
        showPage("dashboard");
        showNotice(existing ? "Deadline updated successfully." : "Deadline saved successfully.");
    }
});

// Study session form submission
$("sessionForm").addEventListener("submit", event => {
    event.preventDefault();

    const id = $("sessionId").value;
    const title = $("sessionTitle").value.trim();
    const subject = $("sessionSubject").value.trim();
    const date = $("sessionDate").value;
    const start = $("sessionStart").value;
    const duration = Number($("sessionDuration").value);
    const shared = $("sessionShare").checked;
    const partner = $("partnerName").value.trim();

    if (!title || !subject || !date || !start || !duration) {
        showNotice("Please complete all required study-session fields.", true);
        return;
    }

    if (!dateFromISO(date)) {
        showNotice("Please enter a valid session date.", true);
        return;
    }

    if (shared && !partner) {
        showNotice("Enter your study partner's name or untick the sharing option.", true);
        $("partnerName").focus();
        return;
    }

    const existing = sessions.find(item => item.id === id);

    const session = {
        id: existing ? existing.id : makeId(),
        title,
        subject,
        deadlineId: $("sessionDeadline").value,
        date,
        start,
        duration,
        notes: $("sessionNotes").value.trim(),
        shared,
        partner: shared ? partner : "",
        completed: existing ? existing.completed : false
    };

    if (existing) {
        sessions = sessions.map(item => item.id === id ? session : item);
    } else {
        sessions.push(session);
    }

    if (saveData()) {
        resetSessionForm();
        refreshAll();
        showPage("dashboard");

        showNotice(
            shared
                ? `Session saved. Sharing with ${partner} is simulated in this prototype.`
                : existing ? "Study session updated." : "Study session saved successfully."
        );
    }
});

// Global click handling for navigation and action buttons

document.addEventListener("click", event => {
    const reminderButton = event.target.closest(
        '[data-action="check-reminders"]'
    );

    if (reminderButton) {
    checkReminders();
    return;
}

    const pageButton = event.target.closest("[data-page]");

    if (pageButton) {
        showPage(pageButton.dataset.page);
        return;
    }

    const questionButton = event.target.closest("[data-question]");

    if (questionButton) {
        askAssistant(questionButton.dataset.question);
        return;
    }

    const actionButton = event.target.closest("[data-action]");
    if (!actionButton) return;

    const action = actionButton.dataset.action;
    const id = actionButton.dataset.id;

    switch (action) {
        case "new-deadline":
            resetDeadlineForm();
            showPage("deadlines");
            $("deadlineTitle").focus();
            break;
        case "new-session":
            resetSessionForm();
            showPage("sessions");
            $("sessionTitle").focus();
            break;
        case "reset-deadline":
            resetDeadlineForm();
            break;
        case "reset-session":
            resetSessionForm();
            break;
        case "edit-deadline":
            editDeadline(id);
            break;
        case "plan-from-deadline":
            planFromDeadline(id);
            break;
        case "delete-deadline":
            deleteDeadline(id);
            break;
        case "edit-session":
            editSession(id);
            break;
        case "complete-session":
            completeSession(id);
            break;
        case "delete-session":
            deleteSession(id);
            break;
        case "view-session":
            openSessionDetails(id);
            break;
        case "check-reminders":
            checkReminders();
            break;
    }
});


// Toggle the optional sharing fields
$("sessionShare").addEventListener("change", () => {
    const enabled = $("sessionShare").checked;

    $("partnerField").hidden = !enabled;
    $("partnerName").required = enabled;

    if (!enabled) $("partnerName").value = "";
});

// Weekly schedule navigation
$("previousWeek").addEventListener("click", () => {
    currentWeek = addDays(currentWeek, -7);
    renderSchedule();
});

$("nextWeek").addEventListener("click", () => {
    currentWeek = addDays(currentWeek, 7);
    renderSchedule();
});

// Session detail dialog actions
$("closeDialog").addEventListener("click", () => {
    $("sessionDialog").close();
});

$("completeSessionButton").addEventListener("click", () => {
    if (selectedSessionId) completeSession(selectedSessionId);
});

$("editSessionButton").addEventListener("click", () => {
    if (selectedSessionId) {
        const id = selectedSessionId;
        $("sessionDialog").close();
        editSession(id);
    }
});

$("deleteSessionButton").addEventListener("click", () => {
    if (selectedSessionId) deleteSession(selectedSessionId);
});

// Conversational interface
function addChatMessage(message, sender) {
    const bubble = document.createElement("div");
    bubble.className = `chat-bubble ${sender}-bubble`;
    bubble.textContent = message;

    $("chatMessages").appendChild(bubble);
    $("chatMessages").scrollTop = $("chatMessages").scrollHeight;
}

function answerQuestion(question) {
    const text = question.toLowerCase();

    if (text.includes("deadline") || text.includes("due date") ||
        text.includes("assignment") || text.includes("exam") ||
        text.includes("test")) {

        const upcoming = sortedDeadlines().filter(deadlineIsUpcoming);

        if (!upcoming.length) {
            return "You don't have any upcoming deadlines recorded. Open Deadlines to add one.";
        }

        return "Here are your upcoming deadlines:\n" +
            upcoming.slice(0, 6).map(item =>
                `• ${item.title} — ${formatDate(item.date)} (${item.subject})`
            ).join("\n");
    }

    if (text.includes("progress") || text.includes("completed") ||
        text.includes("how am i doing")) {

        const completed = sessions.filter(item => item.completed).length;
        const percentage = sessions.length
            ? Math.round(completed / sessions.length * 100)
            : 0;

        return sessions.length
            ? `You've completed ${completed} of ${sessions.length} recorded study sessions (${percentage}%). Keep working at a pace that suits you.`
            : "You haven't recorded any study sessions yet. Create your first session to start tracking your progress.";
    }

    if (text.includes("tomorrow")) {
        const tomorrow = dateISO(addDays(new Date(), 1));
        const items = sortedSessions().filter(item =>
            item.date === tomorrow && !item.completed
        );

        return items.length
            ? "Your planned sessions for tomorrow:\n" + items.map(item =>
                `• ${item.title} at ${formatTime(item.start)}`
            ).join("\n")
            : "You don't have any incomplete study sessions recorded for tomorrow.";
    }

    if (text.includes("today")) {
        const today = todayISO();
        const items = sortedSessions().filter(item =>
            item.date === today && !item.completed
        );

        return items.length
            ? "Your planned sessions for today:\n" + items.map(item =>
                `• ${item.title} at ${formatTime(item.start)}`
            ).join("\n")
            : "You don't have any incomplete study sessions recorded for today.";
    }

    if (text.includes("session") || text.includes("schedule") ||
        text.includes("study plan") || text.includes("planned")) {

        const planned = sortedSessions().filter(sessionIsUpcoming);

        if (!planned.length) {
            return "You don't have any upcoming study sessions. Open Study Sessions to plan one.";
        }

        return "Here are your upcoming study sessions:\n" +
            planned.slice(0, 6).map(item =>
                `• ${item.title} — ${formatDate(item.date)}, ${formatTime(item.start)}`
            ).join("\n");
    }

    if (text.includes("help") || text.includes("what can you do")) {
        return "I can help you review your saved deadlines, planned sessions and progress. Try asking 'What deadlines are coming up?', 'What sessions do I have planned?' or 'How is my progress?'";
    }

    return "I can answer questions about your recorded deadlines, planned study sessions and progress. Try asking about your upcoming deadlines or your schedule for tomorrow.";
}

function askAssistant(question) {
    const trimmed = question.trim();
    if (!trimmed) return;

    addChatMessage(trimmed, "user");

    const reply = answerQuestion(trimmed);
    addChatMessage(reply, "assistant");

    $("chatInput").value = "";
}

$("chatForm").addEventListener("submit", event => {
    event.preventDefault();
    askAssistant($("chatInput").value);
});

function refreshAll() {
    updateDateLabel();
    updateDashboard();
    renderSchedule();
}

function initialise() {
    loadData();

    $("todayLabel").textContent = "";
    resetDeadlineForm();
    resetSessionForm();

    refreshAll();
    showPage("dashboard");
}

initialise();
